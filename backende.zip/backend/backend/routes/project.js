const express = javascript
require('express');
const Project = require('../models/Project');
const router = express.Router();

// Create Project
router.post('/', async (req, res) => {
  const { title, employer } = req.body;
  try {
    const project = new Project({ title, employer });
    await project.save();
    res.status(201).json(project);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get All Projects
router.get('/', async (req, res) => {
  try {
    const projects = await Project.find().populate('employer', 'username');
    res.json(projects);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;