const express = require('express');
const Milestone = require('../models/Milestone');
const router = express.Router();

// Create Milestone
router.post('/', async (req, res) => {
  const { title, project, amount } = req.body;
  try {
    const milestone = new Milestone({ title, project, amount });
    await milestone.save();
    res.status(201).json(milestone);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get All Milestones for a Project
router.get('/:projectId', async (req, res) => {
  try {
    const milestones = await Milestone.find({ project: req.params.projectId });
    res.json(milestones);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;