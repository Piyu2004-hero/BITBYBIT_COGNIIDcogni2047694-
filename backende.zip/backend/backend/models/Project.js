const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  employer: { type: mongoose.Schema.Types.ObjectId, ref: 'User ' },
  milestones: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Milestone' }],
});

module.exports = mongoose.model('Project', ProjectSchema);