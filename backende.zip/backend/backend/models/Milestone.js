const mongoose = require('mongoose');

const MilestoneSchema = new mongoose.Schema({
  title: { type: String, required: true },
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
  completed: { type: Boolean, default: false },
  amount: { type: Number, required: true },
});

module.exports = mongoose.model('Milestone', MilestoneSchema);