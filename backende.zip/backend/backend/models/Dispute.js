const mongoose = require('mongoose');

const DisputeSchema = new mongoose.Schema({
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
  freelancer: { type: mongoose.Schema.Types.ObjectId, ref: 'User ' },
  employer: { type: mongoose.Schema.Types.ObjectId, ref: 'User ' },
  description: { type: String, required: true },
  resolved: { type: Boolean, default: false },
});

module.exports = mongoose.model('Dispute', DisputeSchema);