from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///milestones.db'
db = SQLAlchemy(app)

class Milestone(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(200), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='Pending')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    milestones = Milestone.query.all()
    return render_template('dashboard.html', milestones=milestones)

@app.route('/add_milestone', methods=['POST'])
def add_milestone():
    title = request.form['title']
    description = request.form['description']
    amount = request.form['amount']
    new_milestone = Milestone(title=title, description=description, amount=amount)
    db.session.add(new_milestone)
    db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/approve_milestone/<int:id>')
def approve_milestone(id):
    milestone = Milestone.query.get(id)
    milestone.status = 'Approved'
    db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/dispute/<int:id>', methods=['GET', 'POST'])
def dispute(id):
    if request.method == 'POST':
        # Handle dispute logic here
        return redirect(url_for('dashboard'))
    return render_template('dispute.html', milestone_id=id)

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)